
package connect;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;


public class Attendance {
    static String driverClass="oracle.jdbc.driver.OracleDriver";
    static String url="jdbc:oracle:thin:@localhost:1521:XE";
    static  String username="vsics";
    static String password="vsics";
    static Connection conn=null;
    static Statement stmt=null;
    static ResultSet rs=null;
             
        static{
            try{
            Class.forName(driverClass);
            conn=DriverManager.getConnection(url,username,password);
            stmt=conn.createStatement();            
        }
        catch(Exception e){
            e.printStackTrace();
        }
            
        }
        public static boolean isAdmin(String userName, String password) throws Exception{
            boolean flag=false;
            String sql="select * from admin where username='"+userName+"' AND password='"+password+"'";
            rs=stmt.executeQuery(sql);
            if(rs.next()){
                flag=true;
            }
            else{
                flag=false;
            }
            return flag;
            
        }
    
          public static ResultSet fetch1()throws Exception{
        
            String sql="select * from COURSE_MASTER";
            rs=stmt.executeQuery(sql);
            return rs ;           
        }
    
       
   public static ResultSet fetch2()throws Exception{
            String sql="select * from YEAR_MASTER ORDER BY YEAR";
            rs=stmt.executeQuery(sql);
            return rs;
        }
        
   
   public static ResultSet fetch3()throws Exception{
        
            String sql=" select SEMESTER from SEMESTER_MASTER order by SEMESTER";
            rs=stmt.executeQuery(sql);
             return rs;
        }
   
   public static ResultSet fetchRecord(String n)throws Exception{
        
            String sql=" select * from Student_MASTER where SEMESTER='"+n+"' order by roll_no";
            System.out.println(sql);
            rs=stmt.executeQuery(sql);
             return rs;
        }
    public static int fetch4(String n) throws Exception{
        DateFormat dateFormat=new SimpleDateFormat("dd/MM/yyyy");
        Date d=new Date();
        String datef=dateFormat.format(d).toString();
        DateFormat timeFormat=new SimpleDateFormat("HH:mm:ss");
        Date e=new Date();
        String timef=timeFormat.format(e).toString();
        System.out.println(datef);
        System.out.println(timef);
        String sql="INSERT INTO ATTENDANCE_MASTER ( roll_no, status, d_date, time) Values('"+n+"','PRESENT' ,'"+datef+"','"+timef+"')";
        int p=stmt.executeUpdate(sql);
        System.out.println(p);
        return p;
    }
    
        public static int fetch6(String n) throws Exception{
        DateFormat dateFormat=new SimpleDateFormat("dd/MM/yyyy");
        Date d=new Date();
        String datef=dateFormat.format(d).toString();
        System.out.println(datef);
         DateFormat timeFormat=new SimpleDateFormat("HH:mm:ss");
        Date e=new Date();
        String timef=timeFormat.format(e).toString();
        System.out.println(timef);
              
        String sql="INSERT INTO ATTENDANCE_MASTER ( roll_no, status, d_date, time) Values('"+n+"','ABSENT' ,'"+datef+"','"+timef+"')";
        int p=stmt.executeUpdate(sql);
        System.out.println(p);
        return p;
    }

     public static ResultSet fetch5(String a) throws Exception
        {
            String sql="SELECT Student_master.roll_no, Student_master.name,attendance_master.status,attendance_master.d_date,attendance_master.time FROM Student_master INNER JOIN attendance_master ON Student_master.roll_no=attendance_master.roll_no where Student_master.SEMESTER='"+a+"' order by Attendance_master.roll_no,attendance_master.d_date desc";
            rs=stmt.executeQuery(sql);
            return rs;
        }
    public static ResultSet searchname(String name,String roll) throws Exception{
           String sql="SELECT Student_master.name,attendance_master.status,attendance_master.d_date,attendance_master.time FROM Student_master INNER JOIN attendance_master ON Student_master.roll_no=attendance_master.roll_no where Student_master.name='"+name+"' OR attendance_master.roll_no='"+roll+"'  order by attendance_master.d_date desc";
           System.out.println(sql);
           rs=stmt.executeQuery(sql);
           return rs;
         }
    
    public static ResultSet fetch7(String n)throws Exception{
            String sql="select NAME from STUDENT_MASTER where SEMESTER='"+n+"' ORDER BY name";
            rs=stmt.executeQuery(sql);
            return rs;
         }
    
    public static ResultSet fetch8(String n)throws Exception{
            String sql="select ROLL_NO from STUDENT_MASTER where SEMESTER='"+n+"' ORDER BY ROLL_NO";
            rs=stmt.executeQuery(sql);
            return rs;
            }

    public static ResultSet fetch9()throws Exception{
        
            String sql="SELECT D_DATE FROM ATTENDANCE_MASTER GROUP BY D_DATE ORDER BY D_DATE DESC";
            rs=stmt.executeQuery(sql);
             return rs;
        }
    
   public static ResultSet fetch10()throws Exception{
        
            String sql="SELECT D_DATE FROM ATTENDANCE_MASTER GROUP BY D_DATE ORDER BY D_DATE";
            rs=stmt.executeQuery(sql);
             return rs;
        }
   
      public static ResultSet searchdate(String sem,String from,String to) throws Exception{
           String sql="SELECT Student_master.roll_no, Student_master.name,attendance_master.status,attendance_master.d_date,attendance_master.time FROM Student_master INNER JOIN attendance_master ON Student_master.roll_no=attendance_master.roll_no where  Student_master.semester = '"+sem+"' and attendance_master.d_date between '"+from+"' and '"+to+"'   order by attendance_master.d_date,attendance_master.roll_no";
           System.out.println(sql);
           rs=stmt.executeQuery(sql);
           return rs;
         }

    public static boolean isSecur(String ans) throws SQLException {
        boolean flag=false;
            String sql="select * from securans where answ='"+ans+"'";
            rs=stmt.executeQuery(sql);
            if(rs.next()){
                flag=true;
            }
            else{
                flag=false;
            }
            return flag;
          
        
    }

    public static ResultSet updatePas(String a) throws SQLException {
            String sql="UPDATE ADMIN SET PASSWORD ='"+a+"' ";
            rs=stmt.executeQuery(sql);
            return rs ;           
        
      }
    
    
}   

