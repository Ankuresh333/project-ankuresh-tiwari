
import connect.Attendance;
import java.awt.Dimension;
import java.awt.Toolkit;
import java.awt.event.KeyEvent;
import javax.swing.JOptionPane;


public class SecurQues extends javax.swing.JFrame {

   
    public SecurQues() {
        this.setUndecorated(true);
        this.setVisible(true);
        initComponents();
        Toolkit tk=Toolkit.getDefaultToolkit();
        int xsize = (int)tk.getScreenSize().getWidth();
        int ysize = (int)tk.getScreenSize().getHeight();
        this.setSize(xsize,ysize);
 
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jback = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        exit = new javax.swing.JButton();
        jSecurAnswer = new javax.swing.JTextField();
        jshow = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setPreferredSize(new java.awt.Dimension(1400, 900));
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(204, 204, 204));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel1.setText("        QUESTION:- WHAT IS YOUR GOOD NAME........???????");
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(249, 180, 780, 40));

        jback.setBackground(new java.awt.Color(153, 153, 153));
        jback.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jback.setForeground(new java.awt.Color(0, 51, 51));
        jback.setText("Back");
        jback.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbackActionPerformed(evt);
            }
        });
        jPanel1.add(jback, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 440, 100, 40));

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 36)); // NOI18N
        jLabel2.setText("PLEASE ANSWER THIS SECURITY QUESTION BEFORE PROCEEDING");
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 50, -1, -1));

        exit.setBackground(new java.awt.Color(153, 153, 153));
        exit.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        exit.setText("LOG OUT");
        exit.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        exit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                exitActionPerformed(evt);
            }
        });
        jPanel1.add(exit, new org.netbeans.lib.awtextra.AbsoluteConstraints(1150, 10, 90, 40));

        jSecurAnswer.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                jSecurAnswerFocusGained(evt);
            }
        });
        jSecurAnswer.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jSecurAnswerActionPerformed(evt);
            }
        });
        jSecurAnswer.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jSecurAnswerKeyPressed(evt);
            }
        });
        jPanel1.add(jSecurAnswer, new org.netbeans.lib.awtextra.AbsoluteConstraints(419, 260, 400, 40));

        jshow.setBackground(new java.awt.Color(153, 153, 153));
        jshow.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jshow.setForeground(new java.awt.Color(0, 51, 51));
        jshow.setText("Proceed");
        jshow.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jshowActionPerformed(evt);
            }
        });
        jPanel1.add(jshow, new org.netbeans.lib.awtextra.AbsoluteConstraints(800, 440, 110, 40));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1270, 550));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jbackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbackActionPerformed
        LoginPage frm=new LoginPage();
        frm.setVisible(true);

    }//GEN-LAST:event_jbackActionPerformed

    private void exitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_exitActionPerformed
        int response = JOptionPane.showConfirmDialog(null, "Do you want to finally exit?", "Confirm",JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
        if (response == JOptionPane.YES_OPTION)
        {
            System.exit(0);
        }
        else
        {
            SecurQues frame = new SecurQues();
            frame.setVisible(true);
        }
    }//GEN-LAST:event_exitActionPerformed

    private void jSecurAnswerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jSecurAnswerActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jSecurAnswerActionPerformed

    private void jshowActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jshowActionPerformed

        try{
             if(Attendance.isSecur(jSecurAnswer.getText())){
                  new UpdatePass().setVisible(true);
            }
            else{
                JOptionPane.showMessageDialog(null,"!!!!!!!!!!!!!!...........Invalid Answer........!!!!!!!!!!!!!!!!!!!!");
                new SecurQues().setVisible(true);
            }
        }catch(Exception e){
        e.printStackTrace();
        }
       

    }//GEN-LAST:event_jshowActionPerformed

    private void jSecurAnswerKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jSecurAnswerKeyPressed
       if(evt.getKeyCode()==KeyEvent.VK_ENTER){
        try{
             if(Attendance.isSecur(jSecurAnswer.getText())){
                  new UpdatePass().setVisible(true);
            }
            else{
                JOptionPane.showMessageDialog(null,"!!!!!!!!!!!!!!...........Invalid Answer........!!!!!!!!!!!!!!!!!!!!");
                new SecurQues().setVisible(true);
            }
        }catch(Exception e){
        e.printStackTrace();
        }
       } 
    }//GEN-LAST:event_jSecurAnswerKeyPressed

    private void jSecurAnswerFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jSecurAnswerFocusGained
           jSecurAnswer.setText("");
    }//GEN-LAST:event_jSecurAnswerFocusGained

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(SecurQues.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(SecurQues.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(SecurQues.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(SecurQues.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new SecurQues().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton exit;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JTextField jSecurAnswer;
    private javax.swing.JButton jback;
    private javax.swing.JButton jshow;
    // End of variables declaration//GEN-END:variables
}
