import java.io.FileOutputStream;
import java.io.*;
import java.sql.*; 
import com.itextpdf.text.*;
import com.itextpdf.text.pdf.*;
import connect.Attendance;
import java.sql.ResultSet;

public class Report { 
     void Rep() throws DocumentException, FileNotFoundException, SQLException, Exception{
               
         ResultSet s = Attendance.searchname(SearchRecord.m,SearchRecord.n);
             Document Detail = new Document();
             PdfWriter.getInstance(Detail, new FileOutputStream("Report.pdf"));
             Detail.open();
             //we have four columns in our table
             //create a cell object
             //PdfPCell table_cell;
            if(s.next()){
                 PdfPTable my = new PdfPTable(1);
                  PdfPCell table_cell;
                 String name = s.getString("NAME");
                 table_cell=new PdfPCell(new Phrase(name));
                 my.addCell(table_cell);

                   Detail.add(my);
                  }
                         
             /* Attach report table to PDF */
           
              ResultSet rs = Attendance.searchname(SearchRecord.m,SearchRecord.n);
             PdfPTable my_report_table = new PdfPTable(3);
             //create a cell object
             PdfPCell table_cell;
             
             while (rs.next()) {
                /* String name = rs.getString("NAME");
                 table_cell=new PdfPCell(new Phrase(name));
                 my_report_table.addCell(table_cell);*/
                 String status=rs.getString("STATUS");
                 table_cell=new PdfPCell(new Phrase(status));
                 my_report_table.addCell(table_cell);
                 String date=rs.getString("D_DATE");
                 table_cell=new PdfPCell(new Phrase(date));
                 my_report_table.addCell(table_cell);
                 String time=rs.getString("TIME");
                 table_cell=new PdfPCell(new Phrase(time));
                 my_report_table.addCell(table_cell);
 
             }
             /* Attach report table to PDF */
             Detail.add(my_report_table);
             Detail.close();
             
             /* Close all DB related objects */
         
                               
        }  
              
       }
