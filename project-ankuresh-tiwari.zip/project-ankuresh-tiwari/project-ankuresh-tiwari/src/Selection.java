
import connect.Attendance;
import java.awt.Dimension;
import java.awt.Toolkit;
import java.awt.event.KeyEvent;
import java.sql.ResultSet;
import javax.swing.JOptionPane;





public class Selection extends javax.swing.JFrame { 
        static String a;
    
    
    public Selection() {
        this.setUndecorated(true);
        this.setVisible(true);
        initComponents();
        Toolkit tk=Toolkit.getDefaultToolkit();
        int xsize = (int)tk.getScreenSize().getWidth();
        int ysize = (int)tk.getScreenSize().getHeight();
        this.setSize(xsize,ysize);
 
        combo1();
        combo2();
        combo3();
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel2 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jlab = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jsemester = new javax.swing.JComboBox();
        jcourse = new javax.swing.JComboBox();
        jyear = new javax.swing.JComboBox();
        jshow = new javax.swing.JButton();
        jback = new javax.swing.JButton();
        exit = new javax.swing.JButton();

        jLabel2.setText("jLabel2");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setPreferredSize(new java.awt.Dimension(1400, 900));

        jPanel1.setBackground(new java.awt.Color(204, 204, 204));
        jPanel1.setBorder(javax.swing.BorderFactory.createMatteBorder(8, 8, 8, 8, new java.awt.Color(0, 0, 0)));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jlab.setBackground(new java.awt.Color(0, 0, 0));
        jlab.setFont(new java.awt.Font("Tahoma", 1, 48)); // NOI18N
        jlab.setText("            Select  Students  Details");
        jlab.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jPanel1.add(jlab, new org.netbeans.lib.awtextra.AbsoluteConstraints(228, 30, 920, -1));

        jLabel3.setBackground(new java.awt.Color(0, 51, 51));
        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel3.setText("Course");
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 177, 100, 40));

        jLabel4.setBackground(new java.awt.Color(0, 51, 51));
        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel4.setText("Year");
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 234, 80, 30));

        jLabel5.setBackground(new java.awt.Color(0, 51, 51));
        jLabel5.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel5.setText("Semester");
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 280, 120, 30));

        jsemester.setBackground(new java.awt.Color(153, 153, 153));
        jsemester.setForeground(new java.awt.Color(0, 51, 51));
        jsemester.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jsemesterActionPerformed(evt);
            }
        });
        jsemester.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jsemesterKeyPressed(evt);
            }
        });
        jPanel1.add(jsemester, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 280, 120, 30));

        jcourse.setBackground(new java.awt.Color(153, 153, 153));
        jcourse.setForeground(new java.awt.Color(0, 51, 51));
        jcourse.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jcourseActionPerformed(evt);
            }
        });
        jPanel1.add(jcourse, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 180, 120, 30));

        jyear.setBackground(new java.awt.Color(153, 153, 153));
        jyear.setForeground(new java.awt.Color(0, 51, 51));
        jyear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jyearActionPerformed(evt);
            }
        });
        jPanel1.add(jyear, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 230, 120, 30));

        jshow.setBackground(new java.awt.Color(153, 153, 153));
        jshow.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jshow.setForeground(new java.awt.Color(0, 51, 51));
        jshow.setText("Show");
        jshow.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jshowActionPerformed(evt);
            }
        });
        jPanel1.add(jshow, new org.netbeans.lib.awtextra.AbsoluteConstraints(800, 440, 100, 40));

        jback.setBackground(new java.awt.Color(153, 153, 153));
        jback.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jback.setForeground(new java.awt.Color(0, 51, 51));
        jback.setText("Back");
        jback.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbackActionPerformed(evt);
            }
        });
        jPanel1.add(jback, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 440, 100, 40));

        exit.setBackground(new java.awt.Color(153, 153, 153));
        exit.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        exit.setText("LOG OUT");
        exit.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        exit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                exitActionPerformed(evt);
            }
        });
        jPanel1.add(exit, new org.netbeans.lib.awtextra.AbsoluteConstraints(1170, 20, 90, 40));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 1280, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 554, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
     
    private void jbackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbackActionPerformed
         this.hide();
         
         LoginPage frm=new LoginPage();
         frm.setVisible(true);
    
    }//GEN-LAST:event_jbackActionPerformed
public void combo1()
{
 try{
       
             ResultSet rs = Attendance.fetch1();
             //new Selection().setVisible(true);
             while (rs.next())
              {
                jcourse.addItem(rs.getString("COURSE"));
                System.out.println(rs.getString("COURSE"));
              }       
                 
           }
  catch(Exception e)
  {
      e.printStackTrace();
  }
}
    private void jcourseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jcourseActionPerformed
        
     
     
           
    }//GEN-LAST:event_jcourseActionPerformed

    public void combo2()
{
 try{
       
             ResultSet rs = Attendance.fetch2();
             //new Selection().setVisible(true);
             while (rs.next())
              {
                jyear.addItem(rs.getString("YEAR"));
                System.out.println(rs.getString("YEAR"));
              }       
                  
           }
  catch(Exception e)
  {
      e.printStackTrace();
  }
}
    private void jyearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jyearActionPerformed
       
    }//GEN-LAST:event_jyearActionPerformed
     
    private void jshowActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jshowActionPerformed
        try
        {
            this.a = (String)jsemester.getSelectedItem();
            System.out.println(a);
              new AttendancePortal().setVisible(true);      
            
        }
         catch(Exception e)
  {
      e.printStackTrace();
  }
       
    }//GEN-LAST:event_jshowActionPerformed
 
    public void combo3()
{
 try{
       
             ResultSet rs = Attendance.fetch3();
             //new Selection().setVisible(true);
             while (rs.next())
              {
                jsemester.addItem(rs.getString("SEMESTER"));
                System.out.println(rs.getString("SEMESTER"));
              }       
                  
           }
  catch(Exception e)
  {
      e.printStackTrace();
  }
}
    private void jsemesterActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jsemesterActionPerformed
     
    }//GEN-LAST:event_jsemesterActionPerformed

    private void jsemesterKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jsemesterKeyPressed
        if(evt.getKeyCode()==KeyEvent.VK_ENTER){
             try
        {
            this.a = (String)jsemester.getSelectedItem();
            System.out.println(a);
              new AttendancePortal().setVisible(true);      
            
        }
         catch(Exception e)
  {
      e.printStackTrace();
  }
        }
    }//GEN-LAST:event_jsemesterKeyPressed

    private void exitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_exitActionPerformed
        int response = JOptionPane.showConfirmDialog(null, "Do you want to finally exit?", "Confirm",JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
        if (response == JOptionPane.YES_OPTION)
        {
            System.exit(0);
        }
        else
        {
            Selection frame = new Selection();
            frame.setVisible(true);
        }
    }//GEN-LAST:event_exitActionPerformed

   
   
    
    public static void main(String args[]) {
       
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Selection().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton exit;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JButton jback;
    private javax.swing.JComboBox jcourse;
    private javax.swing.JLabel jlab;
    private javax.swing.JComboBox jsemester;
    private javax.swing.JButton jshow;
    private javax.swing.JComboBox jyear;
    // End of variables declaration//GEN-END:variables
}
