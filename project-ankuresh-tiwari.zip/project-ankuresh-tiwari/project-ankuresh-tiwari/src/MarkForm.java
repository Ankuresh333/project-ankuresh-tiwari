import connect.Attendance;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Toolkit;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.sql.ResultSet;
import java.util.ArrayList;
import javax.swing.JDialog;

public class MarkForm extends JFrame {

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				MarkForm frame = new MarkForm();
				frame.setVisible(true);
			}
		});
	}

	/**
	 * Create the frame.
	 */
	    public MarkForm() {
                   this.setUndecorated(true);
        this.setVisible(true);
    
        Toolkit tk=Toolkit.getDefaultToolkit();
        int xsize = (int)tk.getScreenSize().getWidth();
        int ysize = (int)tk.getScreenSize().getHeight();
        this.setSize(xsize,ysize);
 
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		//setBounds(100, 100, 1100, 600);
		setTitle("Mark Attendance");
		getContentPane().setLayout(null);

		// ScrollPane for Table
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(33, 41, 1100, 600);
		getContentPane().add(scrollPane);

		// Table
		final JTable table = new JTable();
		scrollPane.setViewportView(table);

		// Model for Table
		DefaultTableModel model = new DefaultTableModel() {

			public Class< ?> getColumnClass(int column) {
				switch (column) {
				case 0:
					return Boolean.class;
				case 1:
					return String.class;
				case 2:
					return String.class;
				case 3:
					return String.class;
				case 4:
					return String.class;
				case 5:
					return String.class;
				case 6:
					return String.class;
				default:
					return String.class;
				}
			}
		};
		table.setModel(model);

		model.addColumn("Mark");
		model.addColumn("Roll No");
                model.addColumn("Name");
		model.addColumn("Semester");
                try{
                    Selection p=new Selection();
		    ResultSet rs=Attendance.fetchRecord(p.a);
                    int n=rs.getRow();
                    System.out.println(n);
                 int i=0;
        while(rs.next())
        {
             String d = rs.getString(1);
            String e = rs.getString(2);
            String f = rs.getString(3);
            
            
			model.addRow(new Object[0]);
			model.setValueAt(false, i, 0);
                        model.setValueAt(d, i, 1);

                        model.setValueAt(e, i, 2);

                        model.setValueAt(f, i, 3);

                        //model.setValueAt("Data Col 4", i, 4);

		
		
i++;
            
        }
        }catch(Exception e){
            e.printStackTrace();
        }

		// Data Row
		
		// Get Row Selected
		JButton btnGetRowSelected = new JButton("Submit");
		btnGetRowSelected.addActionListener(new ActionListener() 
                {
			public void actionPerformed(ActionEvent e) 
                        {
                                 ArrayList<String> al=new ArrayList<String>();
                                 ArrayList<String> a2=new ArrayList<String>();
                                 JDialog.setDefaultLookAndFeelDecorated(true);
                                 int response = JOptionPane.showConfirmDialog(null, "Do you want to finally submit?", "Confirm",JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
                                 if (response == JOptionPane.YES_OPTION)
                                 {
				   for (int i = 0; i <table.getRowCount(); i++)
                                   {
					Boolean chked = Boolean.valueOf(table.getValueAt(i, 0)
							.toString());
					String dataCol1 = table.getValueAt(i, 1).toString();
					
                                        if (chked)
                                        {
                                            al.add(dataCol1);
						//JOptionPane.showMessageDialog(null, dataCol1);
                                             try 
                                             {
                                                 Attendance.fetch4(dataCol1);
                                             } 
                                             catch (Exception ex)
                                             {
                                                 ex.printStackTrace();
                                             }   
					}
                                        else
                                        {
                                            a2.add(dataCol1);
                                            try 
                                             {
                                                 Attendance.fetch6(dataCol1);
                                             } 
                                             catch (Exception ex)
                                             {
                                                 ex.printStackTrace();
                                             } 
                                        }
				    } 
                                     JOptionPane.showMessageDialog(null,"Record Submitted");
                                     AttendancePortal frame = new AttendancePortal();
                                     frame.setVisible(true);
                                 }
                                 
                                 else
                                 {
                                     	MarkForm frame = new MarkForm();
                                        frame.setVisible(true);
                                 }
			}

		});
		btnGetRowSelected.setBounds(38,0, 131, 23);
		getContentPane().add(btnGetRowSelected);

        
                JButton goback = new JButton("Back");
		goback.addActionListener(new ActionListener()
                {
		    public void actionPerformed(ActionEvent e)
                    {
                        AttendancePortal f=new AttendancePortal();
                        f.setVisible(true);
                    }
		});
		goback.setBounds(1000,0, 131, 23);
		getContentPane().add(goback);

        }	
}
